# Developing

* Pull requests can be made against https://github.com/drupal-media/dropzonejs/pulls
