# Embed Module

[![Travis build status](https://img.shields.io/travis/drupal-media/embed/8.x-1.x.svg)](https://travis-ci.org/drupal-media/embed) [![Scrutinizer code quality](https://img.shields.io/scrutinizer/g/drupal-media/embed/8.x-1.x.svg)](https://scrutinizer-ci.com/g/drupal-media/embed)

Provides an API for embedding and a UI for creating embed buttons.
